"""6.009 Lab 10: Snek Is You Video Game"""

import doctest

# NO ADDITIONAL IMPORTS!

# All words mentioned in lab. You can add words to these sets,
# but only these are guaranteed to have graphics.
NOUNS = {"SNEK", "FLAG", "ROCK", "WALL", "COMPUTER", "BUG"}
PROPERTIES = {"YOU", "WIN", "STOP", "PUSH", "DEFEAT", "PULL"}
NOT_AND_IS = NOUNS | PROPERTIES
WORDS = NOT_AND_IS | {"AND", "IS"}

direction_vector = { # Maps a keyboard direction to a (delta_row, delta_column) vector.
    "up": (-1, 0),
    "down": (+1, 0),
    "left": (0, -1),
    "right": (0, +1),
}

#initializing text properties
properties = {}

def new_game(level_description):
    """
    Given a description of a game state, create and return a game
    representation of your choice.

    The given description is a list of lists of lists of strs, where UPPERCASE
    strings represent word objects and lowercase strings represent regular
    objects (as described in the lab writeup).

    For example, a valid level_description is:

    [
        [[], ['snek'], []],
        [['SNEK'], ['IS'], ['YOU']],
    ]

    The exact choice of representation is up to you; but note that what you
    return will be used as input to the other functions.

    Representation:
    My board representation was a dictionary where I had each item on the board
    as a key and its respective values were the coordinates of said item.
    """
    global properties
    return_dict = {}
    return_dict['DIMENSIONS'] = (len(level_description), len(level_description[0]))
    for r in range(len(level_description)):
        for c in range(len(level_description[r])):
            if len(level_description[r][c]) > 0:
                for item in level_description[r][c]:
                    try:
                        return_dict[item].append((r, c))
                    except:
                        return_dict[item] = [(r, c)]
    
    properties = properties_new(return_dict)
    return return_dict

def next_to(game, coord, key):
    """
    This checks to see if an item is in a
    given coordinate (next to item of focus)
    """
    
    if game.get(key) and coord in game[key]:
        return True
    return False

def step_game(game, direction):
    """
    Given a game representation (as returned from new_game), modify that game
    representation in-place according to one step of the game.  The user's
    input is given by direction, which is one of the following:
    {'up', 'down', 'left', 'right'}.

    step_game should return a Boolean: True if the game has been won after
    updating the state, and False otherwise.
    """
    global properties
    #moving each object with YOU attribute
    new_coords = set()
    for item in properties['YOU']:
        if game.get(item.lower()):
            for coord in game[item.lower()].copy():
                if move_object(game, direction, coord, item.lower()) == True:
                    new_coords.add((coord[0]+direction_vector[direction][0], coord[1]+direction_vector[direction][1]))
    
    #implementing changing the properties
    properties = properties_new(game)
    
    #changing items where NOUN IS NOUN
    changed_game = {}
    for noun1 in NOUNS: #this is the one that is changing
        if game.get(noun1.lower()):
            for noun2 in NOUNS:
                if properties.get(noun2) and noun1 in properties[noun2]:
                    changed_game[noun2.lower()] = game[noun1.lower()].copy()
                    del game[noun1.lower()] #because there are no more instances of noun1

    for new_key in changed_game:
        try:
            game[new_key] = game[new_key] + changed_game[new_key]
        except:
            game[new_key] = changed_game[new_key]

    #winning or losing
    for you_item in properties['YOU']:
        for coord in new_coords:
            for defeat_item in properties['DEFEAT']:
                if game.get(defeat_item.lower()) and coord in game[defeat_item.lower()]:
                    replacement_number = game[you_item.lower()].count(coord)
                    for i in range(replacement_number):
                        game[you_item.lower()].remove(coord) #removing item from board

    for you_item in properties['YOU']: #checking remaining items with YOU attribute
        if game.get(you_item.lower()):
            for coord in game[you_item.lower()]:
                for win_item in properties['WIN']:
                    if game.get(win_item.lower()) and coord in game[win_item.lower()]:
                        return True
    return False

def properties_new(game):
    """
    This will save a dictionary where each each word (sans AND/IS)
    is a property (aka a key) and the values contain the nouns that
    have said property

    My first step would be to collect all the nouns that are getting
    attributes added to them (1). I do this until I see an IS (2). From there,
    I collect all the properties/nouns and save them in as a set of
    attributes (3). From there, I would loop through the nouns and attributes
    and set each noun to each attribute (4).
    """
    new_properties = {}
    for word in NOT_AND_IS:
        new_properties[word] = set()
    for word in NOUNS: #(1)
        if game.get(word):
            for coord in game[word]:
                down = (coord[0]+1, coord[1])
                right = (coord[0], coord[1]+1)
                if next_to(game, right, 'AND'):
                    nouns = collecter({word}, game, (right[0], right[1]+1), 'right') #(1)
                    new_right = (right[0], right[1]+2*(len(nouns)-1))
                    if next_to(game, new_right, 'IS'): #(2)
                        for property in NOT_AND_IS: #(3)
                            if next_to(game, (new_right[0], new_right[1]+1), property): #if statement going across
                                if next_to(game, (new_right[0], new_right[1]+2), 'AND'):
                                    attributes = collecter({property}, game, (new_right[0], new_right[1]+3), 'right') #(3)
                                    for attribute in attributes:
                                        for noun in nouns:
                                            new_properties[attribute].add(noun) #(4)
                                else:
                                    for noun in nouns:
                                        new_properties[property].add(noun) #(4)
                                break
                
                elif next_to(game, right, 'IS'): #if statement going across (2)
                    for property in NOT_AND_IS: #(3)
                        if next_to(game, (right[0], right[1]+1), property): #if statement going across
                            if next_to(game, (right[0], right[1]+2), 'AND'):
                                attributes = collecter({property}, game, (right[0], right[1]+3), 'right') #(3)
                                for attribute in attributes:
                                    new_properties[attribute].add(word) #(4)
                            else:
                                new_properties[property].add(word) #(4)
                            break

                if next_to(game, down, 'AND'):
                    nouns = {word} | collecter(set(), game, (down[0]+1, down[1]), 'down') #(1)
                    new_down = (down[0]+2*(len(nouns)-1), down[1])
                    if next_to(game, new_down, 'IS'): #(2)
                        for property in NOT_AND_IS: #(3)
                            if next_to(game, (new_down[0]+1, new_down[1]), property): #if statement going down
                                if next_to(game, (new_down[0]+2, new_down[2]), 'AND'):
                                    attributes = collecter({property}, game, (new_down[0]+3, new_down[1]), 'down') #(3)
                                    for attribute in attributes:
                                        for noun in nouns:
                                            new_properties[attribute].add(noun) #(4)
                                else:
                                    for noun in nouns:
                                        new_properties[property].add(noun) #(4)
                                break

                elif next_to(game, down, 'IS'): #if statement going down (2)
                    for property in NOT_AND_IS: #(3)
                        if next_to(game, (down[0]+1, down[1]), property): #if statement going down
                            if next_to(game, (down[0]+2, down[1]), 'AND'):
                                attributes = collecter({property}, game, (down[0]+3, down[1]), 'down') #(3)
                                for attribute in attributes:
                                    new_properties[attribute].add(word) #(4)
                            else:
                                new_properties[property].add(word) #(4)
                            break
    return new_properties

def collecter(sett, game, coord, direction):
    """
    This function goes along a path and collects all
    items that are joined by the AND clause
    """
    way = direction_vector[direction]
    next_coord = (coord[0]+way[0], coord[1] + way[1])
    for word in NOT_AND_IS:
        if game.get(word) and coord in game[word]:
            sett.add(word)
            if next_to(game, next_coord, 'AND'):
                next_next_coord = (next_coord[0]+way[0], next_coord[1]+way[1])
                sett | collecter(sett, game, next_next_coord, direction)
            break
    return sett

def move_object(game, direction, coord, key):
    """
    This will move an object of focus (a YOU object) and
    move the objects surrounding it accordingly

    If an object surrounding has the YOU property, it will
    not move because it will move as a YOU object
    """
    front_x = coord[0]+direction_vector[direction][0]
    front_y = coord[1]+direction_vector[direction][1]
    back_x = coord[0]-direction_vector[direction][0]
    back_y = coord[1]-direction_vector[direction][1]
    #if trying to move outside of boundary
    if front_x >= game['DIMENSIONS'][0] or front_x < 0 or front_y >= game['DIMENSIONS'][1] or front_y < 0:
        return False
    for item in properties['STOP']:
        #functionality for stop objects
        if game.get(item.lower()) and (front_x, front_y) in game[item.lower()]:
            if item not in properties['PUSH'] and item not in properties['YOU']:
                return False

    for item in properties['PUSH']:
        #functionality for push objects
        if game.get(item.lower()) and (front_x, front_y) in game[item.lower()]:
            if item not in properties['YOU']:
                worked = move_object(game, direction, (front_x, front_y), item.lower())
                if worked == False:
                    return False
    
    for item in game:
        #functionality for text objects (pushing)
        #I found it easier to separate the push items and text items
        if item == 'DIMENSIONS':
            continue
        elif item.isupper() and (front_x, front_y) in game[item]:
            worked = move_object(game, direction, (front_x, front_y), item)
            if worked == False:
                return False

    if front_x < game['DIMENSIONS'][0] and front_x >= 0 and front_y < game['DIMENSIONS'][1] or front_y >= 0:
        replacement_number = game[key].count(coord)
        for i in range(replacement_number): #functionality for moving object of interest
            game[key].remove(coord)
            game[key].append((front_x, front_y))
    
    for item in properties['PULL']:
        #functionality for pulling objects
        covered_condition = False
        if game.get(item.lower()) and (back_x, back_y) in game[item.lower()]:
            for you_item in properties['YOU']:
                if game.get(you_item.lower()) and (back_x, back_y) in game[you_item.lower()]:
                    covered_condition = True
                    replacement_number = game[item.lower()].count((back_x, back_y))
                    for i in range(replacement_number):
                        game[item.lower()].remove((back_x, back_y))
                        game[item.lower()].append(coord)
            if covered_condition == False:
                move_object(game, direction, (back_x, back_y), item.lower())

    return True
    
def dump_game(game):
    """
    Given a game representation (as returned from new_game), convert it back
    into a level description that would be a suitable input to new_game.

    This function is used by the GUI and tests to see what your game
    implementation has done, and it can also serve as a rudimentary way to
    print out the current state of your game for testing and debugging on your
    own.
    """
    board = []
    for i in range(game['DIMENSIONS'][0]):
        board.append([])
        for j in range(game['DIMENSIONS'][1]):
            board[i].append([])
            for keys in game:
                count = game[keys].count((i, j))
                for a in range(0, count):
                    board[i][j].append(keys)
    return board

if __name__ == "__main__":
    pass